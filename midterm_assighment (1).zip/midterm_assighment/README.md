# Midterm_assighment

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nur-Islam-Kubanychbekov/pen/WNPxPdR](https://codepen.io/Nur-Islam-Kubanychbekov/pen/WNPxPdR).

